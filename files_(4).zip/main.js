// ============================================
// TOOLTIP ENGINE
// ============================================
const tooltipEl = document.getElementById('tooltip');
let activeTipTarget = null;

function showTooltip(target, key) {
  const def = TOOLTIPS[key];
  if (!def) return;
  tooltipEl.innerHTML = `<strong>${def.label}</strong> — ${def.text}`;
  tooltipEl.classList.add('visible');
  positionTooltip(target);
  activeTipTarget = target;
}

function hideTooltip() {
  tooltipEl.classList.remove('visible');
  activeTipTarget = null;
}

function positionTooltip(target) {
  const rect = target.getBoundingClientRect();
  const tipRect = tooltipEl.getBoundingClientRect();
  let left = rect.left + rect.width / 2 - tipRect.width / 2;
  let top = rect.top - tipRect.height - 12;

  left = Math.max(12, Math.min(left, window.innerWidth - tipRect.width - 12));

  if (top < 8) {
    top = rect.bottom + 12;
  }

  tooltipEl.style.left = `${left}px`;
  tooltipEl.style.top = `${top}px`;
}

function wireTooltipTargets(root = document) {
  root.querySelectorAll('[data-tip]').forEach(el => {
    if (el._tipWired) return;
    el._tipWired = true;
    const key = el.getAttribute('data-tip');

    el.addEventListener('mouseenter', () => showTooltip(el, key));
    el.addEventListener('mouseleave', hideTooltip);
    el.addEventListener('focus', () => showTooltip(el, key));
    el.addEventListener('blur', hideTooltip);

    el.addEventListener('touchstart', (e) => {
      e.preventDefault();
      if (activeTipTarget === el) {
        hideTooltip();
      } else {
        showTooltip(el, key);
      }
    }, { passive: false });

    el.setAttribute('tabindex', '0');
  });
}

window.addEventListener('scroll', () => {
  if (activeTipTarget) positionTooltip(activeTipTarget);
}, { passive: true });

document.addEventListener('touchstart', (e) => {
  if (activeTipTarget && !e.target.closest('[data-tip]')) hideTooltip();
});

// ============================================
// KATEX RENDERING WITH HOVERABLE VARIABLES
// ============================================
// KaTeX doesn't give per-symbol hooks out of the box, so each formula
// is rendered, then we walk the resulting DOM to tag specific glyphs
// with data-tip attributes matching the TOOLTIPS keys.

function renderFormulas() {
  // --- Transmission probability ---
  // T ≈ exp( -(2d/ℏ) * sqrt(2 m φ) )
  const tLatex = String.raw`T \approx \exp\!\left(-\frac{2d}{\hbar}\sqrt{2m\phi}\right)`;
  katex.render(tLatex, document.getElementById('formula-T'), {
    throwOnError: false,
    displayMode: true
  });

  // --- Tunnel resistance ---
  // R_T = 1/(σA) = (h^2 d) / (e^2 A * 2mφ) * exp( (2d/ℏ) * sqrt(2mφ) )
  const rtLatex = String.raw`R_T = \frac{1}{\sigma \mathcal{A}} = \frac{h^2\, d}{e^2 \mathcal{A} \cdot 2m\phi}\, \exp\!\left(\frac{2d}{\hbar}\sqrt{2m\phi}\right)`;
  katex.render(rtLatex, document.getElementById('formula-RT'), {
    throwOnError: false,
    displayMode: true
  });

  // --- Total island capacitance ---
  // C_Σ = C_S + C_D + C_G
  const csumLatex = String.raw`C_\Sigma = C_S + C_D + C_G`;
  katex.render(csumLatex, document.getElementById('formula-Csum'), {
    throwOnError: false,
    displayMode: true
  });

  // --- General charge sensitivity ---
  // δq = sqrt(S) / max|∂(signal)/∂q|
  const dqLatex = String.raw`\delta q = \frac{\sqrt{S}}{\left|\dfrac{\partial(\text{signal})}{\partial q}\right|}`;
  katex.render(dqLatex, document.getElementById('formula-dq'), {
    throwOnError: false,
    displayMode: true
  });

  // --- SET charge sensitivity ---
  // δq = sqrt(S_I) / max|∂I_ds/∂q|
  const dqsetLatex = String.raw`\delta q = \frac{\sqrt{S_I}}{\max\left|\dfrac{\partial I_{ds}}{\partial q}\right|}`;
  katex.render(dqsetLatex, document.getElementById('formula-dqset'), {
    throwOnError: false,
    displayMode: true
  });

  // --- Max slope of SET current response to charge ---
  const maxdIdqLatex = String.raw`\max\left|\frac{\partial I_{ds}}{\partial q}\right|`;
  katex.render(maxdIdqLatex, document.getElementById('formula-maxdIdq'), {
    throwOnError: false,
    displayMode: true
  });

  // --- Theoretical optimum charge sensitivity (Devoret & Schoelkopf) ---
  const dqoptLatex = String.raw`\delta Q_{\text{opt}} \approx 1.7 \times 10^{-6}\ e/\sqrt{\text{Hz}}`;
  katex.render(dqoptLatex, document.getElementById('formula-dqopt'), {
    throwOnError: false,
    displayMode: true
  });

  tagKatexVariables();
}

// Walk rendered KaTeX spans and attach data-tip to the right glyphs.
// KaTeX renders each math identifier as its own .mord (or similar) span
// containing exactly that character, so we can match by text content
// within a scoped container, in order, without disturbing layout.
function tagKatexVariables() {
  tagFormula(document.getElementById('formula-T'), [
    { match: 'T', key: 'T' },
    { match: 'd', key: 'd' },
    { match: 'ℏ', key: 'hbar' },
    { match: 'm', key: 'm' },
    { match: 'ϕ', key: 'phi' },
    { match: 'φ', key: 'phi' }
  ]);

  tagFormula(document.getElementById('formula-RT'), [
    { match: 'R', key: 'RT' },
    { match: 'h', key: 'h' },
    { match: 'd', key: 'd' },
    { match: 'e', key: 'e' },
    { match: 'A', key: 'A' },
    { match: 'm', key: 'm' },
    { match: 'ϕ', key: 'phi' },
    { match: 'φ', key: 'phi' },
    { match: 'ℏ', key: 'hbar' }
  ]);
}

function tagFormula(container, rules) {
  if (!container) return;
  // Find leaf spans that are single-glyph mord/mop tokens.
  // KaTeX sometimes wraps a glyph in a .mord that contains another
  // .mord with the same text (e.g. ℏ render as <mord><mord>ℏ</mord></mord>).
  // Only tag genuine leaves — spans with no element children — so we
  // don't double-tag both the wrapper and the glyph inside it.
  const spans = container.querySelectorAll('.mord, .mop');
  spans.forEach(span => {
    if (span._tipTagged) return;
    if (span.children.length > 0) return; // not a leaf, skip wrapper
    const text = span.textContent.trim();
    if (!text) return;

    for (const rule of rules) {
      if (text === rule.match) {
        span.classList.add('mathvar-hover');
        span.setAttribute('data-tip', rule.key);
        span.setAttribute('spellcheck', 'false');
        span._tipTagged = true;
        wireTooltipTargets(container);
        break;
      }
    }
  });

  // Note: "exp" renders as a single .mop leaf span in KaTeX (not split
  // into e/x/p characters). It's intentionally left untagged — no
  // tooltip is defined for it.
}

// ============================================
// WIDGET: single junction Coulomb gap
// ============================================
function initSingleJunctionWidget() {
  const sj = document.getElementById('sj');
  if (!sj) return;

  const VTH = 35, K = 0.846;
  const bias = document.getElementById('sj-bias'),
        status = document.getElementById('sj-status'),
        dot = document.getElementById('sj-dot'),
        ivm = document.getElementById('sj-ivm'),
        lq = document.getElementById('sj-lq'),
        rq = document.getElementById('sj-rq');

  function cur(V) {
    const a = Math.abs(V);
    return a > VTH ? Math.sign(V) * (a - VTH) * K : 0;
  }

  const pts = [];
  for (let V = -100; V <= 100; V += 2) {
    const x = 340 + V / 100 * 270, y = 95 - cur(V);
    pts.push(x.toFixed(1) + ',' + y.toFixed(1));
  }
  document.getElementById('sj-iv').setAttribute('points', pts.join(' '));

  function setSign(g, sym, col) {
    g.querySelectorAll('text').forEach(t => {
      t.textContent = sym;
      t.setAttribute('fill', col);
    });
  }

  function render() {
    const V = +bias.value;
    const a = Math.abs(V), cond = a > VTH;
    sj.setAttribute('class', cond ? (V > 0 ? 'fwd' : 'rev') : 'blocked');
    const op = Math.min(1, a / 55);
    if (V >= 0) {
      setSign(lq, '+', 'var(--signal)');
      setSign(rq, '−', 'var(--accent)');
    } else {
      setSign(lq, '−', 'var(--accent)');
      setSign(rq, '+', 'var(--signal)');
    }
    lq.setAttribute('opacity', op);
    rq.setAttribute('opacity', op);
    if (cond) {
      dot.style.background = 'var(--accent)';
      status.textContent = 'Conducting — electrons tunnel across';
    } else {
      dot.style.background = 'var(--signal)';
      status.textContent = 'Coulomb blockade — current suppressed';
    }
    ivm.setAttribute('cx', (340 + V / 100 * 270).toFixed(1));
    ivm.setAttribute('cy', (95 - cur(V)).toFixed(1));
  }

  bias.addEventListener('input', render);
  render();
}

// ============================================
// WIDGET: gate-tuned charge ladder
// ============================================
function initLadderWidget() {
  const svg = document.getElementById('lad');
  if (!svg) return;

  const WC = 200, SP = 120, PER = 50, WTOP = 170, WBOT = 230;
  const levels = document.getElementById('lad-levels'),
        ecb = document.getElementById('lad-ecbracket'),
        gate = document.getElementById('lad-gate'),
        status = document.getElementById('lad-status'),
        dot = document.getElementById('lad-dot'),
        marker = document.getElementById('lad-ivmarker');

  function ys(g) {
    const off = (g / PER) * SP, a = [];
    for (let k = -3; k <= 3; k++) a.push(WC + SP / 2 - off + k * SP);
    return a;
  }

  function nearest(g) {
    let m = 1e9;
    ys(g).forEach(y => { m = Math.min(m, Math.abs(y - WC)); });
    return m;
  }

  function cur(g) {
    return Math.exp(-Math.pow(nearest(g) / 22, 2));
  }

  const pts = [];
  for (let g = 0; g <= 100; g++) {
    const x = 60 + g / 100 * 560, y = 100 - cur(g) * 68;
    pts.push(x.toFixed(1) + ',' + y.toFixed(1));
  }
  document.getElementById('lad-ivcurve').setAttribute('points', pts.join(' '));

  function render() {
    const g = +gate.value;
    const L = ys(g);
    let cond = false, s = '';
    L.forEach(y => {
      if (y < 78 || y > 362) return;
      const hit = (y >= WTOP && y <= WBOT);
      if (hit) cond = true;
      const col = hit ? 'var(--accent)' : 'var(--color-text-primary)';
      const w = hit ? 3 : 1.5, op = hit ? 1 : 0.4;
      s += `<line x1="280" y1="${y}" x2="400" y2="${y}" stroke="${col}" stroke-width="${w}" opacity="${op}" stroke-linecap="round"/>`;
    });
    levels.innerHTML = s;

    const sorted = L.slice().sort((a, b) => a - b);
    let top = null, bot = null;
    for (let i = 1; i < sorted.length; i++) {
      if (sorted[i - 1] < WC && sorted[i] >= WC) {
        top = sorted[i - 1];
        bot = sorted[i];
        break;
      }
    }
    if (top === null) { top = sorted[0]; bot = sorted[1]; }

    ecb.innerHTML =
      `<line x1="414" y1="${top}" x2="414" y2="${bot}" stroke="var(--color-text-secondary)" stroke-width="1"/>` +
      `<line x1="410" y1="${top}" x2="418" y2="${top}" stroke="var(--color-text-secondary)" stroke-width="1"/>` +
      `<line x1="410" y1="${bot}" x2="418" y2="${bot}" stroke="var(--color-text-secondary)" stroke-width="1"/>` +
      `<text class="lbl" x="423" y="${(top + bot) / 2 + 4}">2E_C</text>`;

    svg.setAttribute('class', cond ? 'conducting' : 'blocked');
    if (cond) {
      dot.style.background = 'var(--accent)';
      status.textContent = 'Conducting — electrons pass one at a time';
    } else {
      dot.style.background = 'var(--signal)';
      status.textContent = 'Coulomb blockade — current suppressed';
    }
    marker.setAttribute('cx', (60 + g / 100 * 560).toFixed(1));
    marker.setAttribute('cy', (100 - cur(g) * 68).toFixed(1));
  }

  gate.addEventListener('input', render);
  render();
}

// ============================================
// INIT
// ============================================
document.addEventListener('DOMContentLoaded', () => {
  renderFormulas();
  wireTooltipTargets();
  initSingleJunctionWidget();
  initLadderWidget();
});
