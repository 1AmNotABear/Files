// Single source of truth for variable tooltips.
// d, hbar, m, phi are shared between the transmission (T) and
// tunnel resistance (R_T) formulas, so they're defined once here
// and referenced by key everywhere a formula variable is hoverable.

const TOOLTIPS = {
  T: {
    label: "T",
    text: "Transmission probability: the likelihood an electron tunnels through the barrier rather than reflecting. A dimensionless value in [0, 1], approaching 0 for thick or tall barriers."
  },
  d: {
    label: "d",
    text: "Barrier thickness."
  },
  hbar: {
    label: "ℏ",
    text: "Reduced Planck constant."
  },
  h: {
    label: "h",
    text: "Planck constant."
  },
  m: {
    label: "m",
    text: "Electron effective mass inside the dielectric, not the metal."
  },
  phi: {
    label: "φ",
    text: "Barrier height: the conduction-band offset between electrode and dielectric, i.e. how far it sits above the electron's energy. Expressed in joules."
  },
  e: {
    label: "e",
    text: "Charge of an electron."
  },
  A: {
    label: "𝒜",
    text: "Junction area, the electrode overlap across the barrier."
  },
  RT: {
    label: "Rₜ",
    text: "Tunnel resistance (Ω): how readily electrons tunnel across the junction."
  }
};
